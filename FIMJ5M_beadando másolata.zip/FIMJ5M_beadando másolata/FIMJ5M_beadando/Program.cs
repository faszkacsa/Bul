﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FIMJ5M_beadando
{
    class Program
    {
        


        static void Main(string[] args)
        {
            
            
            

            Menu menu = new Menu();
            int menuDontes = menu.Dontes();
            Console.Clear();
           if (menuDontes == 1)
            {
                Tabla tabla = new Tabla(0, 0);

                tabla.TablaKirajzol();
/*
                Console.WriteLine("Piros játékos neve:");
                string pirosJatekos = Console.ReadLine();
                Console.WriteLine("Fehér játékos neve:");
                string feherJatekos = Console.ReadLine();

                int pirosJatekosLepese = 1;
                int feherJatekosLepese = 0;

                Jatekos elsoJatekos = new Jatekos(pirosJatekos, pirosJatekosLepese);
                Jatekos masodikJatekos = new Jatekos(feherJatekos, feherJatekosLepese);
                */
                


            }
            if (menuDontes == 3)
            {
                Console.WriteLine("A játék bezárul.");
            }
            Console.ReadKey();
        }

        public void Lepes(Jatekos jatekos, Babu [,] tabla)
        {
            Dobokocka kocka = new Dobokocka();
            int dobotSzam = kocka.Dobas();
            
            if (jatekos.JatekosLogikai == false)
            {
                for (int i = 0; i < dobotSzam; i++)
                {
                    Console.WriteLine("Hányas számú bábuval lépsz?");
                    int babu = int.Parse(Console.ReadLine());
                    
                    ConsoleKeyInfo nyil = Console.ReadKey();

                    switch (nyil.Key)
                    {

                        case ConsoleKey.LeftArrow:


                            break;

                        default:
                            Console.WriteLine("nem az");
                            break;
                    }
                }
            }
            


        }


    }
    

}
