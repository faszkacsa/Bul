﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FIMJ5M_beadando
{
    class Jatekos
    {
        string jatekosNev;
        bool jatekosLogikai;
        Babu[] jatekosBabui;
        public Jatekos(string jatekos, bool logikai)
        { 
            this.jatekosNev = jatekos;
            this.jatekosLogikai = logikai;
        }
   
        public string JatekosNev
        {
            get { return jatekosNev; }
        }
        public bool JatekosLogikai
        {
            get { return jatekosLogikai; }
        }

    }
}
