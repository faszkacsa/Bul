﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FIMJ5M_beadando
{
    class Tabla
    {
        Babu[,] palya;
        public Tabla(int sor, int oszlop)
        {
            palya = new Babu[sor, oszlop];
            KezdoAllas(sor, oszlop);
        }

        public void Kirajzol()
        {
            Console.WriteLine();
            for (int i = 0; i < palya.GetLength(0); i++)
            {
                
                for (int j = 0; j < palya.GetLength(1); j++)
                {
                    
                    if (palya[i, j] != null)
                    {

                        if (palya[i, j].BabuSzin)
                        {
                            Console.ForegroundColor = ConsoleColor.White;
                            if (palya[i, j].BabuID < 10 && palya[i,j].BabuSzin == false)
                            {
                                Console.Write("  " + palya[i, j].BabuID + " ");
                            }
                            else
                            {
                                Console.Write(" " + palya[i, j].BabuID + " ");
                            }
                          
                        }
                        else
                        {

                            Console.ForegroundColor = ConsoleColor.Red;
                            if (palya[i, j].BabuID < 10 && palya[i, j].BabuSzin == false)
                            {
                                Console.Write("  " + palya[i, j].BabuID + " ");
                            }
                            else
                            {
                                Console.Write(" " + palya[i, j].BabuID + " ");
                            }
                            

                        }
                        
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Blue;
                        Console.Write(" X ");
                    }

                }
                Console.WriteLine();
            }

        }

        private void KezdoAllas( int sor, int oszlop)
        {
            for (int i = 0; i < sor; i++)
            {
                Babu B1 = new Babu(i, 0, i, false);
                Babu B2 = new Babu(i, oszlop - 1, i, true);
                palya[B1.BabuSOR, B1.BabuOSZLOP] = B1;
                palya[B2.BabuSOR, B2.BabuOSZLOP] = B2;
             
                
            }
        }

        public void JatekosLetrehozas()
        {
            Console.WriteLine("Első játékos neve");
            Jatekos jatekos1 = new Jatekos(Console.ReadLine(),false);
            Console.WriteLine("Második játékos neve");
            Jatekos jatekos2 = new Jatekos(Console.ReadLine(),true);

        }
        public void TablaKirajzol()
        {
            JatekosLetrehozas();
            int sor, oszlop;
            Console.WriteLine("Tábla mérete(hosszúkás legyen, páros oszlopszámmal):");
            sor = int.Parse(Console.ReadLine());
            oszlop = int.Parse(Console.ReadLine());
            int szamlalo = 1;

            if ((oszlop > sor && oszlop % 2 == 0) && (sor != 0))
            {
                Console.WriteLine(szamlalo + ". alkalomra kaptam jó táblát");
                Tabla tabla = new Tabla(sor, oszlop);
                tabla.Kirajzol();
            }
            else
            {
                do
                {
                    Console.WriteLine("Rossz tábla méret, kérem adjon meg újat:");
                    sor = int.Parse(Console.ReadLine());
                    oszlop = int.Parse(Console.ReadLine());
                    szamlalo++;
                } while (!((oszlop > sor && oszlop % 2 == 0) && (sor != 0)));
                if (oszlop > sor && oszlop % 2 == 0)
                {
                    Console.WriteLine(szamlalo + ". alkalomra kaptam jó táblát");
                    Tabla tabla = new Tabla(sor, oszlop);
                    tabla.Kirajzol();
                }
            }

        }

    }
}
