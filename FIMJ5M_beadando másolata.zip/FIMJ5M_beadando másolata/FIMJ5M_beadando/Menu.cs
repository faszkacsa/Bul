﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FIMJ5M_beadando
{
    class Menu
    {
        public int Dontes()
        {
            Console.WriteLine("Kérem válassza ki, hogy az alábbi opciók közül melyiket szeretné:");
            Console.WriteLine("1: Új játék kezdete");
            Console.WriteLine("2: Játék betöltése");
            Console.WriteLine("3: Kilépés");
            int menu = int.Parse(Console.ReadLine());

            return menu;

        }
        


    }
}
